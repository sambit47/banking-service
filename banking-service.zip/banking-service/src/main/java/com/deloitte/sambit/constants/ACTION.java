package com.deloitte.sambit.constants;

public enum ACTION {
    DEPOSIT,
    WITHDRAW
}
